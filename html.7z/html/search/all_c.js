var searchData=
[
  ['toggledebug_72',['ToggleDebug',['../class_game.html#ab518c46604c896ffe21fdb9765c9504d',1,'Game']]],
  ['toggledestroy_73',['ToggleDestroy',['../class_destroyables.html#a77bc8c117860b9a88819785ad070aeb4',1,'Destroyables']]]
];
