var searchData=
[
  ['game_31',['Game',['../class_game.html',1,'']]],
  ['game_2ecpp_32',['Game.cpp',['../_game_8cpp.html',1,'']]],
  ['game_2eh_33',['Game.h',['../_game_8h.html',1,'']]],
  ['getcentre_34',['getCentre',['../class_camera.html#ae02bb64506df49be130b22d2caf5193f',1,'Camera::getCentre()'],['../class_player.html#a1692b828289881361b802562693a2ee2',1,'Player::getCentre()']]],
  ['gethealth_35',['getHealth',['../class_player.html#abcb15d249bed9a4ab0ab86b52b0d747a',1,'Player']]],
  ['getinstance_36',['getInstance',['../class_game.html#a19798a4f4c50037e1c5cd8c5d491fef9',1,'Game::getInstance()'],['../class_player.html#a8a5e9b9c50dfc47114dbff9efbe5c67c',1,'Player::getInstance()']]],
  ['getposition_37',['getPosition',['../class_player.html#a47211aa9ba86b0cde7722dd6198a4b45',1,'Player']]],
  ['getrotation_38',['getRotation',['../class_player.html#aa2890f51b31e33f439f6bd67092168f7',1,'Player']]],
  ['getshapes_39',['getShapes',['../class_debug_draw.html#a8f99d75a83b314b079ae06f2d2a18f04',1,'DebugDraw']]],
  ['getsprite_40',['getSprite',['../class_player.html#aabef659f696be314cdb705a1ce77ec2a',1,'Player']]],
  ['getview_41',['getView',['../class_camera.html#a7d7fb981ba8de6b73acf76da98f8004c',1,'Camera']]],
  ['getworld_42',['getWorld',['../class_game.html#a7fd5a947ab90c7f4d7558f204f53e33b',1,'Game']]]
];
